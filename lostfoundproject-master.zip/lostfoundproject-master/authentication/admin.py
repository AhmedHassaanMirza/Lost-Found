from django.contrib import admin
from .models import ImageData

admin.site.register(ImageData)

# Register your models here.
