from django.apps import AppConfig
from insightface_code.functions import FaceRec as FC
import pickle5 as pickle
class FaceRec(AppConfig):
        default_auto_field = 'django.db.models.BigAutoField'
        name = 'authentication'

	
        
